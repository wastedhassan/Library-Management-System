package Utilities;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Validator {

    // ================== USER VALIDATION ==================

    public static String validateUserId(Scanner sc) {
        while (true) {
            System.out.print("Enter User ID (S/T/A followed by digits, e.g., S1001): ");
            String id = sc.nextLine().trim();

            if (id.isEmpty()) {
                System.out.println("User ID cannot be empty. Try again.");
                continue;
            }

            char prefix = id.charAt(0);
            if (prefix != 'S' && prefix != 'T' && prefix != 'A') {
                System.out.println("User ID must start with S (Student), T (Teacher), or A (Admin).");
                continue;
            }

            try {
                Integer.parseInt(id.substring(1));
                return id;
            } catch (NumberFormatException e) {
                System.out.println("User ID must have digits after the prefix. Try again.");
            }
        }
    }

    public static String validateUserName(Scanner sc) {
        while (true) {
            System.out.print("Enter name: ");
            String name = sc.nextLine().trim();

            if (name.isEmpty()) {
                System.out.println("Name cannot be empty. Try again.");
                continue;
            }

            if (name.length() < 2) {
                System.out.println("Name must be at least 2 characters.");
                continue;
            }

            return name;
        }
    }

    public static String validateUserEmail(Scanner sc) {
        while (true) {
            System.out.print("Enter email: ");
            String email = sc.nextLine().trim().toLowerCase();

            if (email.isEmpty()) {
                System.out.println("Email cannot be empty. Try again.");
                continue;
            }

            if (!email.contains("@") || !email.contains(".")) {
                System.out.println("Invalid email format. Must contain '@' and '.'");
                continue;
            }

            return email;
        }
    }

    public static String validateUserPassword(Scanner sc) {
        while (true) {
            System.out.print("Enter password (min 4 chars): ");
            String password = sc.nextLine().trim();

            if (password.length() < 4) {
                System.out.println("Password must be at least 4 characters.");
                continue;
            }

            System.out.print("Confirm password: ");
            String confirm = sc.nextLine().trim();

            if (!password.equals(confirm)) {
                System.out.println("Passwords do not match. Try again.");
                continue;
            }

            return password;
        }
    }

    public static String validateUserContact(Scanner sc) {
        while (true) {
            System.out.print("Enter contact number (digits only, 10-15 chars): ");
            String contact = sc.nextLine().trim().replaceAll("\\s+", "");

            if (contact.isEmpty()) {
                return ""; // Allow empty contact
            }

            if (!contact.matches("\\d+")) {
                System.out.println("Contact must contain only digits.");
                continue;
            }

            if (contact.length() < 10 || contact.length() > 15) {
                System.out.println("Contact must be 10-15 digits.");
                continue;
            }

            return contact;
        }
    }

    public static int validateMaxBooksAllowed(Scanner sc, String role) {
        while (true) {
            System.out.print("Enter max books allowed for " + role + ": ");
            try {
                int max = sc.nextInt();
                sc.nextLine(); // Clear buffer

                if (max < 1) {
                    System.out.println("Must allow at least 1 book.");
                    continue;
                }

                if (max > 50) {
                    System.out.println("Maximum cannot exceed 50 books.");
                    continue;
                }

                return max;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid integer.");
                sc.nextLine(); // Clear invalid input
            }
        }
    }

    // ================== BOOK VALIDATION ==================

    public static String validateISBN(Scanner sc) {
        while (true) {
            System.out.print("Enter ISBN (13 digits): ");
            String isbn = sc.nextLine().trim().replaceAll("-", "");

            if (isbn.length() != 13) {
                System.out.println("ISBN must be exactly 13 digits.");
                continue;
            }

            if (!isbn.matches("\\d{13}")) {
                System.out.println("ISBN must contain only digits.");
                continue;
            }

            return isbn;
        }
    }

    public static String validateBookTitle(Scanner sc) {
        while (true) {
            System.out.print("Enter book title: ");
            String title = sc.nextLine().trim();

            if (title.isEmpty()) {
                System.out.println("Title cannot be empty.");
                continue;
            }

            if (title.length() < 2) {
                System.out.println("Title too short.");
                continue;
            }

            return title;
        }
    }

    public static String validateBookAuthor(Scanner sc) {
        while (true) {
            System.out.print("Enter author name: ");
            String author = sc.nextLine().trim();

            if (author.isEmpty()) {
                System.out.println("Author cannot be empty.");
                continue;
            }

            return author;
        }
    }

    public static int validatePublicationYear(Scanner sc) {
        int currentYear = LocalDate.now().getYear();
        while (true) {
            System.out.print("Enter publication year (1000-" + currentYear + "): ");
            try {
                int year = sc.nextInt();
                sc.nextLine(); // Clear buffer

                if (year < 1000 || year > currentYear) {
                    System.out.println("Year must be between 1000 and " + currentYear + ".");
                    continue;
                }

                return year;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid year.");
                sc.nextLine(); // Clear invalid input
            }
        }
    }

    public static double validateBookPrice(Scanner sc) {
        while (true) {
            System.out.print("Enter price (0 for free): $");
            try {
                double price = sc.nextDouble();
                sc.nextLine(); // Clear buffer

                if (price < 0) {
                    System.out.println("Price cannot be negative.");
                    continue;
                }

                if (price > 10000) {
                    System.out.println("Price seems too high. Confirm? (Y/N): ");
                    String confirm = sc.nextLine().trim().toLowerCase();
                    if (!confirm.equals("y") && !confirm.equals("yes")) {
                        continue;
                    }
                }

                return price;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid price.");
                sc.nextLine(); // Clear invalid input
            }
        }
    }

    // ================== DATE VALIDATION ==================

    public static LocalDate validateDate(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt + " (YYYY-MM-DD or press Enter for today): ");
            String input = sc.nextLine().trim();

            if (input.isEmpty()) {
                return LocalDate.now();
            }

            try {
                return LocalDate.parse(input);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Use YYYY-MM-DD.");
            }
        }
    }

    public static LocalDate validateFutureDate(Scanner sc, String prompt) {
        while (true) {
            LocalDate date = validateDate(sc, prompt);

            if (date.isBefore(LocalDate.now())) {
                System.out.println("Date cannot be in the past.");
                continue;
            }

            return date;
        }
    }

    // ================== MENU VALIDATION ==================


    public static boolean validateYesNo(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String input = sc.nextLine().trim().toLowerCase();

            if (input.equals("y") || input.equals("yes")) {
                return true;
            } else if (input.equals("n") || input.equals("no")) {
                return false;
            } else {
                System.out.println("Please enter Y or N.");
            }
        }
    }

    // ================== QUICK VALIDATORS (for setters) ==================

    public static void validateNonEmpty(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
    }

    public static void validatePositive(int value, String fieldName) {
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " cannot be negative.");
        }
    }

    public static void validatePositive(double value, String fieldName) {
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " cannot be negative.");
        }
    }

    public static void validateInRange(int value, int min, int max, String fieldName) {
        if (value < min || value > max) {
            throw new IllegalArgumentException(
                    fieldName + " must be between " + min + " and " + max + "."
            );
        }
    }
}


