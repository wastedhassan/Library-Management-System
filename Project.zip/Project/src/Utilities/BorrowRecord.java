package Utilities;

import Book.Book;
import User.User;
import java.time.LocalDate;

public class BorrowRecord {

    private User user;
    private Book book;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private boolean isReturned;

    public BorrowRecord() {
        this.borrowDate = LocalDate.now();
        this.dueDate = borrowDate.plusDays(14); // 2 weeks default
        this.isReturned = false;
    }
    public BorrowRecord(User user, Book book) {
        this();
        this.user = user;
        this.book = book;
    }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Book getBook() { return book; }
    public void setBook(Book book) { this.book = book; }

    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) { this.borrowDate = borrowDate; }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }

    public boolean isReturned() { return isReturned; }
    public void setReturned(boolean returned) { isReturned = returned; }


    public void markAsReturned() {
        this.returnDate = LocalDate.now();
        this.isReturned = true;
    }

    public boolean isOverdue() {
        return !isReturned && LocalDate.now().isAfter(dueDate);
    }

    @Override
    public String toString() {
        return String.join(",",
                user.getId(),
                book.getIsbn(),
                borrowDate.toString(),
                dueDate.toString(),
                returnDate != null ? returnDate.toString() : "null",
                Boolean.toString(isReturned)
        );
    }




}
