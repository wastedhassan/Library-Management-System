package Utilities;

class BookNotAvailableException extends Exception {
    private String isbn;
    private String title;

    public BookNotAvailableException(String isbn, String title) {
        super("Book '" + title + "' (ISBN: " + isbn + ") is not available for borrowing.");
        this.isbn = isbn;
        this.title = title;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
}
