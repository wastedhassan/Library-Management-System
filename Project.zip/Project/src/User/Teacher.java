package User;

public class Teacher extends User {
    private String teacherId;
    private String faculty;
    private String designation;

    // Constructors
    public Teacher() {
        super();
        this.teacherId = "";
        this.faculty = "";
        this.designation = "";
    }

    public Teacher(String id, String name, String email, String password,
                   String teacherId, String faculty, String designation,
                   String contact, int maxBooksAllowed) {
        super(id, name, email, password, "Teacher", contact, maxBooksAllowed);
        this.teacherId = teacherId;
        this.faculty = faculty;
        this.designation = designation;
    }

    // Getters and Setters
    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }

    public String getFaculty() { return faculty; }
    public void setFaculty(String faculty) { this.faculty = faculty; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    // toString - includes type identifier at the end
    @Override
    public String toString() {
        return super.toString() + "," +
                String.join(",", teacherId, faculty, designation, "teacher");
    }
}