package User;

public class Administrator extends User {
    private String department;
    private String employeeId;

    // Constructors
    public Administrator() {
        super();
        this.department = "Library";
        this.employeeId = "";
    }

    public Administrator(String id, String name, String email, String password,
                         String department, String employeeId, String contact,
                         int maxBooksAllowed) {
        super(id, name, email, password, "Admin", contact, maxBooksAllowed);
        this.department = department;
        this.employeeId = employeeId;
    }

    // Getters and Setters
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    // toString
    @Override
    public String toString() {
        return super.toString() + "," +
                String.join(",", department, employeeId,"administrator");
    }
}