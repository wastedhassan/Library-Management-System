package User;

public class Student extends User {
    private String studentId;  // ADDED
    private String enrollmentYear;
    private String degree;  // ADDED (was missing)

    // Constructors
    public Student() {
        super();
        this.studentId = "";
        this.enrollmentYear = "";
        this.degree = "";
    }

    public Student(String id, String name, String email, String password,
                   String studentId, String enrollmentYear, String contact,
                   int maxBooksAllowed, String degree) {
        super(id, name, email, password, "Student", contact, maxBooksAllowed);
        this.studentId = studentId;
        this.enrollmentYear = enrollmentYear;
        this.degree = degree;
    }

    // Getters and Setters
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getEnrollmentYear() { return enrollmentYear; }
    public void setEnrollmentYear(String enrollmentYear) {
        this.enrollmentYear = enrollmentYear;
    }

    public String getDegree() { return degree; }  // ADDED
    public void setDegree(String degree) { this.degree = degree; }  // ADDED

    // toString
    @Override
    public String toString() {
        return super.toString() + "," +
                String.join(",", studentId, enrollmentYear, degree,"student");
    }
}