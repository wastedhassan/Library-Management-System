package Library;

import Book.*;
import FileHandling.FileManager;
import User.*;
import Utilities.BorrowRecord;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Library library;

    private static Scanner ob= new Scanner(System.in);

    private static User currentUser = null;

     static void main(String[] args) {
        library = new Library();

        System.out.println("=== DIGITAL LIBRARY SYSTEM ===");
        loadData();
        mainMenu();
        saveData();
        ob.close();
    }

    //ABOUT DATA LOADING AND STORING
    private static void loadData() {
        System.out.println("Loading data...");

        FileManager fileManager = new FileManager();

        // 1. Load books
        ArrayList<Book> books = fileManager.loadBooks();
        library.setBooksList(books);

        // 2. Load users
        ArrayList<User> users = fileManager.loadUsers();
        library.setUsersList(users);

        // 3. Load borrow records (needs books + users)
        ArrayList<BorrowRecord> records = fileManager.loadBorrowedRecords(users, books);
        library.setBorrowRecordsList(records);

        System.out.println("Data loaded successfully.");
    }

    private static void saveData() {
        System.out.println("Saving data...");

        FileManager fileManager = new FileManager();

        fileManager.saveBooks(library.getBooksList());
        fileManager.saveUsers(library.getUsersList());
        fileManager.saveBorrowedRecords(library.getBorrowRecordsList());

        System.out.println("Data saved successfully.");
    }
    //MAIN PROGRAM MENU
    private static void mainMenu() {
        while (true) {
            System.out.println("\n=== MAIN MENU ===");
            System.out.println("1. Admin Login");
            System.out.println("2. Teacher Login");
            System.out.println("3. Student Login");
            System.out.println("4. Exit");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> adminLogin();
                    case 2 -> teacherLogin();
                    case 3 -> studentLogin();
                    case 4 -> {
                        System.out.println("Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid choice (1-4).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    //USER LOGINS
    private static void adminLogin() {
        System.out.print("Enter Admin ID: ");
        String id = ob.nextLine();
        currentUser = library.getUserById(id);

        if (currentUser != null && currentUser.getRole().equals("Admin")) {
            System.out.println("Welcome, " + currentUser.getName() + "!");
            adminMenu();
        } else {
            System.out.println("Invalid Admin ID.");
            currentUser = null;
        }
    }

    private static void teacherLogin() {
        System.out.print("Enter Teacher ID: ");
        String id = ob.nextLine();
        currentUser = library.getUserById(id);

        if (currentUser != null && currentUser.getRole().equals("Teacher")) {
            System.out.println("Welcome, " + currentUser.getName() + "!");
            teacherMenu();
        } else {
            System.out.println("Invalid Teacher ID.");
            currentUser = null;
        }
    }

    private static void studentLogin() {
        System.out.print("Enter Student ID: ");
        String id = ob.nextLine();
        currentUser = library.getUserById(id);

        if (currentUser != null && currentUser.getRole().equals("Student")) {
            System.out.println("Welcome, " + currentUser.getName() + "!");
            studentMenu();
        } else {
            System.out.println("Invalid Student ID.");
            currentUser = null;
        }
    }

    //SUB MENUS
    private static void adminMenu() {
        while (true) {
            System.out.println("\n=== ADMIN MENU ===");
            System.out.println("1. Manage Books");
            System.out.println("2. Manage Users");
            System.out.println("3. View Reports");
            System.out.println("4. Logout");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> manageBooksMenu();
                    case 2 -> manageUsersMenu();
                    case 3 -> reportsMenu();
                    case 4 -> {
                        currentUser = null;
                        return;
                    }
                    default -> System.out.println("Invalid choice (1-4).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void teacherMenu() {
        while (true) {
            System.out.println("\n=== TEACHER MENU ===");
            System.out.println("1. Search Books");
            System.out.println("2. Borrow Book");
            System.out.println("3. Return Book");
            System.out.println("4. My Borrowed Books");
            System.out.println("5. Logout");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> searchBooksMenu();
                    case 2 -> borrowBookMenu();
                    case 3 -> returnBookMenu();
                    case 4 -> viewMyBorrowedBooks();
                    case 5 -> {
                        currentUser = null;
                        return;
                    }
                    default -> System.out.println("Invalid choice (1-5).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void studentMenu() {
        while (true) {
            System.out.println("\n=== STUDENT MENU ===");
            System.out.println("1. Search Books");
            System.out.println("2. Borrow Book");
            System.out.println("3. Return Book");
            System.out.println("4. My Borrowed Books");
            System.out.println("5. Logout");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> searchBooksMenu();
                    case 2 -> borrowBookMenu();
                    case 3 -> returnBookMenu();
                    case 4 -> viewMyBorrowedBooks();
                    case 5 -> {
                        currentUser = null;
                        return;
                    }
                    default -> System.out.println("Invalid choice (1-5).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    // ========== BOOK MANAGEMENT ==========

    private static void manageBooksMenu() {
        while (true) {
            System.out.println("\n--- BOOK MANAGEMENT ---");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Search Book");
            System.out.println("4. View All Books");
            System.out.println("5. Back");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> addBook();
                    case 2 -> removeBook();
                    case 3 -> searchBooksMenu();
                    case 4 -> viewAllBooks();
                    case 5 -> { return; }
                    default -> System.out.println("Invalid choice (1-5).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void addBook() {
        System.out.println("\n--- ADD BOOK ---");

        System.out.println("Select book type:");
        System.out.println("1. Physical Book");
        System.out.println("2. E-Book");
        System.out.println("3. PlayBook");
        System.out.print("Choose: ");

        int type;
        try {
            type = ob.nextInt();
            ob.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid input.");
            ob.nextLine();
            return;
        }

        // Common fields
        System.out.print("Enter ISBN: ");
        String isbn = ob.nextLine();
        System.out.print("Enter title: ");
        String title = ob.nextLine();
        System.out.print("Enter author: ");
        String author = ob.nextLine();

        System.out.print("Enter publication year: ");
        int year;
        try {
            year = ob.nextInt();
            ob.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid year.");
            ob.nextLine();
            return;
        }

        System.out.print("Enter price: ");
        double price;
        try {
            price = ob.nextDouble();
            ob.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid price.");
            ob.nextLine();
            return;
        }

        Book book = null;

        switch (type) {
            case 1 -> { // Physical
                System.out.print("Enter shelf location: ");
                String shelf = ob.nextLine();
                System.out.print("Enter weight (g): ");
                double weight;
                try {
                    weight = ob.nextDouble();
                    ob.nextLine();
                } catch (Exception e) {
                    System.out.println("Invalid weight.");
                    ob.nextLine();
                    return;
                }
                book = new PhysicalBook(isbn, title, author, year, price, shelf, weight);
            }
            case 2 -> { // E-Book
                System.out.print("Enter file size (MB): ");
                double size;
                try {
                    size = ob.nextDouble();
                    ob.nextLine();
                } catch (Exception e) {
                    System.out.println("Invalid size.");
                    ob.nextLine();
                    return;
                }
                System.out.print("Enter download link: ");
                String link = ob.nextLine();
                System.out.print("Enter format: ");
                String format = ob.nextLine();
                book = new EBook(isbn, title, author, year, price, size, link, format);
            }
            case 3 -> { // PlayBook
                System.out.print("Enter duration (minutes): ");
                int duration;
                try {
                    duration = ob.nextInt();
                    ob.nextLine();
                } catch (Exception e) {
                    System.out.println("Invalid duration.");
                    ob.nextLine();
                    return;
                }
                System.out.print("Enter media type: ");
                String media = ob.nextLine();
                System.out.print("Enter compatible device: ");
                String device = ob.nextLine();
                book = new PlayBook(isbn, title, author, year, price, duration, media, device);
            }
            default -> {
                System.out.println("Invalid book type.");
                return;
            }
        }

        if (library.addBook(book)) {
            System.out.println("Book added successfully!");
        } else {
            System.out.println("Failed to add book. ISBN might already exist.");
        }
    }

    private static void removeBook() {
        System.out.println("\n--- REMOVE BOOK ---");
        System.out.print("Enter ISBN to remove: ");
        String isbn = ob.nextLine();

        if (library.removeBook(isbn)) {
            System.out.println("Book removed successfully!");
        } else {
            System.out.println("Book not found or currently borrowed.");
        }
    }

    // ========== USER MANAGEMENT ==========

    private static void manageUsersMenu() {
        while (true) {
            System.out.println("\n--- USER MANAGEMENT ---");
            System.out.println("1. Add User");
            System.out.println("2. View All Users");
            System.out.println("3. Back");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> addUser();
                    case 2 -> viewAllUsers();
                    case 3 -> { return; }
                    default -> System.out.println("Invalid choice (1-3).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void addUser() {
        System.out.println("\n--- ADD USER ---");
        System.out.println("Select user type:");
        System.out.println("1. Student");
        System.out.println("2. Teacher");
        System.out.println("3. Admin");
        System.out.print("Choose: ");

        int type;
        try {
            type = ob.nextInt();
            ob.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid input.");
            ob.nextLine();
            return;
        }

        System.out.print("Enter ID: ");
        String id = ob.nextLine();
        System.out.print("Enter name: ");
        String name = ob.nextLine();
        System.out.print("Enter email: ");
        String email = ob.nextLine();
        System.out.print("Enter password: ");
        String password = ob.nextLine();
        System.out.print("Enter contact: ");
        String contact = ob.nextLine();

        System.out.print("Enter max books allowed: ");
        int maxBooks;
        try {
            maxBooks = ob.nextInt();
            ob.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid number.");
            ob.nextLine();
            return;
        }

        User user = null;

        switch (type) {
            case 1 -> { // Student
                System.out.print("Enter enrollment year: ");
                String year = ob.nextLine();
                System.out.print("Enter degree: ");
                String degree = ob.nextLine();
                user = new Student(id, name, email, password, id, year, contact, maxBooks, degree);
            }
            case 2 -> { // Teacher
                System.out.print("Enter faculty: ");
                String faculty = ob.nextLine();
                System.out.print("Enter designation: ");
                String designation = ob.nextLine();
                user = new Teacher(id, name, email, password, id, faculty, designation, contact, maxBooks);
            }
            case 3 -> { // Admin
                System.out.print("Enter department: ");
                String dept = ob.nextLine();
                System.out.print("Enter employee ID: ");
                String empId = ob.nextLine();
                user = new Administrator(id, name, email, password, dept, empId, contact, maxBooks);
            }
            default -> {
                System.out.println("Invalid user type.");
                return;
            }
        }

        if (library.addUser(user)) {
            System.out.println("User added successfully!");
        } else {
            System.out.println("Failed to add user. ID might already exist.");
        }
    }

    // ========== REPORTS ==========

    private static void reportsMenu() {
        while (true) {
            System.out.println("\n--- REPORTS ---");
            System.out.println("1. View All Books");
            System.out.println("2. View All Users");
            System.out.println("3. View Borrowed Books");
            System.out.println("4. View Available Books");
            System.out.println("5. Back");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> viewAllBooks();
                    case 2 -> viewAllUsers();
                    case 3 -> viewBorrowedBooks();
                    case 4 -> viewAvailableBooks();
                    case 5 -> { return; }
                    default -> System.out.println("Invalid choice (1-5).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void viewAllBooks() {
        System.out.println("\n--- ALL BOOKS ---");
        ArrayList<Book> books = library.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books in library.");
            return;
        }
        for (Book book : books) {
            System.out.println("- " + book.getTitle() + " by " + book.getAuthor() +
                    " (ISBN: " + book.getIsbn() + ") - " +
                    (book.isAvailable() ? "Available" : "Borrowed"));
        }
    }

    private static void viewAllUsers() {
        System.out.println("\n--- ALL USERS ---");
        ArrayList<User> users = library.getAllUsers();
        if (users.isEmpty()) {
            System.out.println("No users registered.");
            return;
        }
        for (User user : users) {
            System.out.println("- " + user.getName() + " (" + user.getId() +
                    ") - " + user.getRole());
        }
    }

    private static void viewBorrowedBooks() {
        System.out.println("\n--- BORROWED BOOKS ---");
        int count = library.getBorrowedBooksCount();
        System.out.println("Total borrowed books: " + count);
    }

    private static void viewAvailableBooks() {
        System.out.println("\n--- AVAILABLE BOOKS ---");
        ArrayList<Book> books = library.getAvailableBooks();
        if (books.isEmpty()) {
            System.out.println("No available books.");
            return;
        }
        for (Book book : books) {
            System.out.println("- " + book.getTitle() + " by " + book.getAuthor() +
                    " (ISBN: " + book.getIsbn() + ")");
        }
    }

    // ========== SEARCH ==========

    private static void searchBooksMenu() {
        while (true) {
            System.out.println("\n--- SEARCH BOOKS ---");
            System.out.println("1. Search by ISBN");
            System.out.println("2. Search by Title");
            System.out.println("3. Search by Author");
            System.out.println("4. View Available Books");
            System.out.println("5. Back");
            System.out.print("Choose: ");

            try {
                int choice = ob.nextInt();
                ob.nextLine();

                switch (choice) {
                    case 1 -> searchByISBN();
                    case 2 -> searchByTitle();
                    case 3 -> searchByAuthor();
                    case 4 -> viewAvailableBooks();
                    case 5 -> { return; }
                    default -> System.out.println("Invalid choice (1-5).");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Enter a number.");
                ob.nextLine();
            }
        }
    }

    private static void searchByISBN() {
        System.out.print("Enter ISBN: ");
        String isbn = ob.nextLine();
        Book book = library.searchBookByIsbn(isbn);

        if (book == null) {
            System.out.println("Book not found.");
        } else {
            System.out.println("Found: " + book.getTitle() + " by " + book.getAuthor() +
                    " - " + (book.isAvailable() ? "Available" : "Borrowed"));
        }
    }

    private static void searchByTitle() {
        System.out.print("Enter title: ");
        String title = ob.nextLine();
        ArrayList<Book> books = library.searchBooksByTitle(title);

        if (books.isEmpty()) {
            System.out.println("No books found.");
        } else {
            System.out.println("Found " + books.size() + " book(s):");
            for (Book book : books) {
                System.out.println("- " + book.getTitle() + " by " + book.getAuthor() +
                        " (ISBN: " + book.getIsbn() + ") - " +
                        (book.isAvailable() ? "Available" : "Borrowed"));
            }
        }
    }

    private static void searchByAuthor() {
        System.out.print("Enter author: ");
        String author = ob.nextLine();
        ArrayList<Book> books = library.searchBooksByAuthor(author);

        if (books.isEmpty()) {
            System.out.println("No books found.");
        } else {
            System.out.println("Found " + books.size() + " book(s):");
            for (Book book : books) {
                System.out.println("- " + book.getTitle() + " by " + book.getAuthor() +
                        " (ISBN: " + book.getIsbn() + ") - " +
                        (book.isAvailable() ? "Available" : "Borrowed"));
            }
        }
    }

    // ========== BORROW/RETURN ==========

    private static void borrowBookMenu() {
        if (currentUser == null) {
            System.out.println("Please login first.");
            return;
        }

        System.out.println("\n--- BORROW BOOK ---");
        System.out.print("Enter ISBN of book to borrow: ");
        String isbn = ob.nextLine();

        if (library.borrowBook(isbn, currentUser.getId())) {
            System.out.println("Book borrowed successfully!");
        } else {
            System.out.println("Failed to borrow book.");
        }
    }

    private static void returnBookMenu() {
        if (currentUser == null) {
            System.out.println("Please login first.");
            return;
        }

        System.out.println("\n--- RETURN BOOK ---");
        System.out.print("Enter ISBN of book to return: ");
        String isbn = ob.nextLine();

        if (library.returnBook(isbn)) {
            System.out.println("Book returned successfully!");
        } else {
            System.out.println("Failed to return book.");
        }
    }

    private static void viewMyBorrowedBooks() {
        if (currentUser == null) {
            System.out.println("Please login first.");
            return;
        }

        System.out.println("\n--- MY BORROWED BOOKS ---");
        ArrayList<Book> books = library.getUserBorrowedBooks(currentUser.getId());

        if (books.isEmpty()) {
            System.out.println("You have no borrowed books.");
        } else {
            System.out.println("You have borrowed " + books.size() + " book(s):");
            for (Book book : books) {
                System.out.println("- " + book.getTitle() + " by " + book.getAuthor() +
                        " (ISBN: " + book.getIsbn() + ")");
            }
        }
    }
}