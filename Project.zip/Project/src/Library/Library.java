package Library;

import Book.*;
import User.*;
import Utilities.BorrowRecord;
import java.util.ArrayList;
import java.util.HashMap;

public class Library {
    private ArrayList<Book> books;
    private ArrayList<User> users;
    private ArrayList<BorrowRecord> allBorrowRecords; // For file saving

    // Fast lookups
    private HashMap<String, Book> isbnToBookMap;
    private HashMap<String, User> idToUserMap;
    private HashMap<User, ArrayList<BorrowRecord>> userToActiveRecords; // Active borrows per user
    private HashMap<Book, BorrowRecord> bookToActiveRecord; // Which book is borrowed by whom

    public Library() {
        books = new ArrayList<>();
        users = new ArrayList<>();
        allBorrowRecords = new ArrayList<>();

        isbnToBookMap = new HashMap<>();
        idToUserMap = new HashMap<>();
        userToActiveRecords = new HashMap<>();
        bookToActiveRecord = new HashMap<>();
    }

    // ========== BOOK METHODS ==========

    public boolean addBook(Book book) {
        if (isbnToBookMap.containsKey(book.getIsbn())) {
            return false; // ISBN exists
        }
        books.add(book);
        isbnToBookMap.put(book.getIsbn(), book);
        return true;
    }

    public boolean removeBook(String isbn) {
        Book book = isbnToBookMap.get(isbn);
        if (book == null) return false;

        // Check if book is currently borrowed
        if (bookToActiveRecord.containsKey(book)) {
            return false; // Cannot remove borrowed book
        }

        books.remove(book);
        isbnToBookMap.remove(isbn);
        return true;
    }

    public Book searchBookByIsbn(String isbn) {
        return isbnToBookMap.get(isbn);
    }

    public ArrayList<Book> searchBooksByTitle(String title) {
        ArrayList<Book> results = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(title.toLowerCase())) {
                results.add(book);
            }
        }
        return results;
    }

    public ArrayList<Book> searchBooksByAuthor(String author) {
        ArrayList<Book> results = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().toLowerCase().contains(author.toLowerCase())) {
                results.add(book);
            }
        }
        return results;
    }

    public ArrayList<Book> getAllBooks() {
        return new ArrayList<>(books);
    }

    // ========== USER METHODS ==========

    public boolean addUser(User user) {
        if (idToUserMap.containsKey(user.getId())) {
            return false; // ID exists
        }
        users.add(user);
        idToUserMap.put(user.getId(), user);
        userToActiveRecords.put(user, new ArrayList<>());
        return true;
    }

    public User getUserById(String id) {
        return idToUserMap.get(id);
    }

    public ArrayList<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    // ========== BORROWING METHODS ==========

    public boolean borrowBook(String isbn, String userId) {
        Book book = isbnToBookMap.get(isbn);
        if (book == null) return false;

        User user = idToUserMap.get(userId);
        if (user == null) return false;

        // Check availability
        if (!book.isAvailable()) {
            System.out.println("Book is not available.");
            return false;
        }

        // Check user's borrowing limit
        ArrayList<BorrowRecord> userRecords = userToActiveRecords.get(user);

        if (userRecords.size() >= user.getMaxBooksAllowed()) {
            System.out.println("User has reached borrowing limit.");
            return false;
        }

        // Create borrow record
        BorrowRecord record = new BorrowRecord(user, book);
        allBorrowRecords.add(record);
        userRecords.add(record);
        bookToActiveRecord.put(book, record);
        book.setAvailable(false);

        System.out.println("Book borrowed successfully.");
        return true;
    }

    public boolean returnBook(String isbn) {
        Book book = isbnToBookMap.get(isbn);
        if (book == null) return false;

        BorrowRecord record = bookToActiveRecord.get(book);
        if (record == null) {
            System.out.println("This book was not borrowed.");
            return false;
        }

        // Mark as returned
        record.markAsReturned();
        User user = record.getUser();

        // Remove from active records
        userToActiveRecords.get(user).remove(record);
        bookToActiveRecord.remove(book);
        book.setAvailable(true);

        System.out.println("Book returned successfully.");
        return true;
    }

    public ArrayList<Book> getUserBorrowedBooks(String userId) {
        User user = idToUserMap.get(userId);
        if (user == null) return new ArrayList<>();

        ArrayList<Book> borrowedBooks = new ArrayList<>();
        for (BorrowRecord record : userToActiveRecords.get(user)) {
            borrowedBooks.add(record.getBook());
        }
        return borrowedBooks;
    }

    public ArrayList<BorrowRecord> getUserBorrowRecords(String userId) {
        User user = idToUserMap.get(userId);
        if (user == null) return new ArrayList<>();
        return new ArrayList<>(userToActiveRecords.get(user));
    }

    public ArrayList<Book> getAvailableBooks() {
        ArrayList<Book> available = new ArrayList<>();
        for (Book book : books) {
            if (book.isAvailable()) {
                available.add(book);
            }
        }
        return available;
    }

    // ========== STATS & UTILITY ==========

    public int getTotalBooks() {
        return books.size();
    }

    public int getTotalUsers() {
        return users.size();
    }

    public int getBorrowedBooksCount() {
        return bookToActiveRecord.size();
    }

    public boolean isBookAvailable(String isbn) {
        Book book = isbnToBookMap.get(isbn);
        return book != null && book.isAvailable();
    }

    public int getUserBorrowedCount(String userId) {
        User user = idToUserMap.get(userId);
        if (user == null) return 0;
        return userToActiveRecords.get(user).size();
    }

    // ========== FILE MANAGER INTEGRATION ==========

    public ArrayList<Book> getBooksList() { return books; }
    public ArrayList<User> getUsersList() { return users; }
    public ArrayList<BorrowRecord> getBorrowRecordsList() { return allBorrowRecords; }

    public void setBooksList(ArrayList<Book> books) {
        this.books = books;
        // Rebuild map
        isbnToBookMap.clear();
        for (Book book : books) {
            isbnToBookMap.put(book.getIsbn(), book);
        }
    }

    public void setUsersList(ArrayList<User> users) {
        this.users = users;
        // Rebuild maps
        idToUserMap.clear();
        userToActiveRecords.clear();
        for (User user : users) {
            idToUserMap.put(user.getId(), user);
            userToActiveRecords.put(user, new ArrayList<>());
        }
    }

    public void setBorrowRecordsList(ArrayList<BorrowRecord> records) {
        this.allBorrowRecords = records;
        // Rebuild active records maps
        bookToActiveRecord.clear();
        for (User user : userToActiveRecords.keySet()) {
            userToActiveRecords.get(user).clear();
        }

        for (BorrowRecord record : records) {
            if (!record.isReturned()) {
                User user = record.getUser();
                Book book = record.getBook();
                userToActiveRecords.get(user).add(record);
                bookToActiveRecord.put(book, record);
                book.setAvailable(false);
            }
        }
    }
}