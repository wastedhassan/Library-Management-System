package Book;

public class PlayBook extends Book {

    private int durationMinutes;
    private String mediaType;
    private String compatibleDevice;

        // Constructors
        public PlayBook() {
            super();
            this.durationMinutes = 0;
            this.mediaType = "Audio";
            this.compatibleDevice = "Mobile";
        }

        public PlayBook(String isbn, String title, String author, int year, double price,
                        int durationMinutes, String mediaType, String compatibleDevice) {
            super(isbn, title, author, year, price);
            this.durationMinutes = durationMinutes;
            this.mediaType = mediaType;
            this.compatibleDevice = compatibleDevice;
        }

        // Getters and Setters
        public int getDurationMinutes() {
            return durationMinutes;
        }
        public void setDurationMinutes(int durationMinutes) {
            this.durationMinutes = durationMinutes;
        }

        public String getMediaType() {
            return mediaType;
        }
        public void setMediaType(String mediaType) {
            this.mediaType = mediaType;
        }

        public String getCompatibleDevice() {
            return compatibleDevice;
        }
        public void setCompatibleDevice(String compatibleDevice) {
            this.compatibleDevice = compatibleDevice;
        }

        @Override
        public String toString() {

            return String.join(",", super.toString(), Integer.toString(durationMinutes), mediaType,
                    compatibleDevice,"playbook"
            );
        }


    }


