package Book;

public class PhysicalBook extends Book {

    private String shelfLocation;
    private double weight;

    // Constructors
    public PhysicalBook() {
        super();
        this.shelfLocation = "";
        this.weight = 0.0;
    }

    public PhysicalBook(String isbn, String title, String author, int year, double price,
                        String shelfLocation, double weight) {
        super(isbn, title, author, year, price);
        this.shelfLocation = shelfLocation;
        this.weight = weight;
    }

    // Getters and Setters
    public String getShelfLocation() {
        return shelfLocation;
    }

    public void setShelfLocation(String shelfLocation) {
        this.shelfLocation = shelfLocation;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return String.join(",", super.toString(),
                shelfLocation, Double.toString(weight),"physicalbook");
    }
}
