package Book;

public class EBook extends Book{

    private double fileSizeMB;
    private String downloadLink;
    private String format;

    public EBook() {
        super();
        this.fileSizeMB = 0.0;
        this.downloadLink = "";
        this.format = "PDF";
    }

    public EBook(String isbn, String title, String author, int year, double price,
                 double fileSizeMB, String downloadLink, String format) {
        super(isbn, title, author, year, price);
        this.fileSizeMB = fileSizeMB;
        this.downloadLink = downloadLink;
        this.format = format;
    }

    public double getFileSizeMB() {
        return fileSizeMB;
    }
    public void setFileSizeMB(double fileSizeMB) {
        this.fileSizeMB = fileSizeMB;
    }

    public String getDownloadLink() {
        return downloadLink;
    }
    public void setDownloadLink(String downloadLink) {
        this.downloadLink = downloadLink;
    }

    public String getFormat() {
        return format;
    }
    public void setFormat(String format) {
        this.format = format;
    }

    public String toString() {
        return String.join(",",
                super.toString(), Double.toString(fileSizeMB), downloadLink, format, "ebook");
    }
}
