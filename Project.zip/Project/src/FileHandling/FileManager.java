package FileHandling;

import Book.*;
import User.*;
import Utilities.BorrowRecord;  // ADDED
import java.io.*;
import java.time.LocalDate;      // ADDED
import java.util.ArrayList;

public class FileManager {
    private static final String BOOKS_FILE = "books.txt";
    private static final String USERS_FILE = "users.txt";
    private static final String BORROWED_FILE = "borrowed.txt";

    // Fixed makeBookObj - check type correctly
    static Book makeBookObj(String line) {
        String[] parts = line.split(",");
        if (parts.length < 6) return null;

        String isbn = parts[0];
        String title = parts[1];
        String author = parts[2];
        int year = Integer.parseInt(parts[3]);
        double price = Double.parseDouble(parts[4]);

        // Type is now at index 5 (after price)
        String type = parts[5].toLowerCase();  // Normalize case

        switch (type) {
            case "physicalbook":
                if (parts.length >= 9) {
                    String shelfLocation = parts[6];
                    double weight = Double.parseDouble(parts[7]);
                    boolean available = Boolean.parseBoolean(parts[8]);

                    PhysicalBook pb = new PhysicalBook(isbn, title, author, year, price,
                            shelfLocation, weight);
                    pb.setAvailable(available);
                    return pb;
                }
                break;

            case "ebook":
                if (parts.length >= 10) {
                    double fileSizeMB = Double.parseDouble(parts[6]);
                    String downloadLink = parts[7];
                    String format = parts[8];
                    boolean available = Boolean.parseBoolean(parts[9]);

                    EBook eb = new EBook(isbn, title, author, year, price,
                            fileSizeMB, downloadLink, format);
                    eb.setAvailable(available);
                    return eb;
                }
                break;

            case "playbook":
                if (parts.length >= 11) {
                    int durationMinutes = Integer.parseInt(parts[6]);
                    String mediaType = parts[7];
                    String compatibleDevice = parts[8];
                    boolean available = Boolean.parseBoolean(parts[9]);

                    PlayBook pb = new PlayBook(isbn, title, author, year, price,
                            durationMinutes, mediaType, compatibleDevice);
                    pb.setAvailable(available);
                    return pb;
                }
                break;
        }
        return null;
    }

    // Fixed makeUserObj - updated for new User structure
    static User makeUserObj(String line) {
        String[] parts = line.split(",");
        if (parts.length < 5) return null;

        String id = parts[0];
        String name = parts[1];
        String email = parts[2];
        String password = parts[3];
        String role = parts[4];
        String contact = parts[5];
        int maxBooksAllowed = Integer.parseInt(parts[6]);

        switch (role) {
            case "Student":
                if (parts.length >= 10) {
                    String studentId = parts[7];
                    String enrollmentYear = parts[8];
                    String degree = parts[9];

                    return new Student(id, name, email, password,
                            studentId, enrollmentYear, contact,
                            maxBooksAllowed, degree);
                }
                break;

            case "Teacher":
                if (parts.length >= 10) {
                    String teacherId = parts[7];
                    String faculty = parts[8];
                    String designation = parts[9];

                    return new Teacher(id, name, email, password,
                            teacherId, faculty, designation,
                            contact, maxBooksAllowed);
                }
                break;

            case "Admin":
                if (parts.length >= 9) {
                    String department = parts[7];
                    String employeeId = parts[8];

                    return new Administrator(id, name, email, password,
                            department, employeeId,
                            contact, maxBooksAllowed);
                }
                break;
        }
        return null;
    }

    // Rest of the methods remain similar but corrected:

    public ArrayList<Book> loadBooks() {
        ArrayList<Book> books = new ArrayList<>();
        try (BufferedReader bookbr = new BufferedReader(new FileReader(BOOKS_FILE))) {
            String line;
            while ((line = bookbr.readLine()) != null) {
                Book book = makeBookObj(line);
                if (book != null) books.add(book);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Books file not found. Starting fresh.");
        } catch (IOException e) {
            System.out.println("Error reading books file.");
        }
        return books;
    }

    public void saveBooks(ArrayList<Book> books) {
        try (BufferedWriter bookbw = new BufferedWriter(new FileWriter(BOOKS_FILE))) {
            for (Book book : books) {
                bookbw.write(book.toString());
                bookbw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving books file.");
        }
    }

    public ArrayList<User> loadUsers() {
        ArrayList<User> users = new ArrayList<>();
        try (BufferedReader userbr = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = userbr.readLine()) != null) {
                User user = makeUserObj(line);
                if (user != null) users.add(user);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Users file not found. Starting fresh.");
        } catch (IOException e) {
            System.out.println("Error reading users file.");
        }
        return users;
    }

    public void saveUsers(ArrayList<User> users) {
        try (BufferedWriter userbw = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users) {
                userbw.write(user.toString());
                userbw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving users file.");
        }
    }

    // BorrowRecord methods
    private BorrowRecord makeBorrowObj(String line, ArrayList<User> users, ArrayList<Book> books) {
        String[] parts = line.split(",");
        if (parts.length != 6) return null;

        String userId = parts[0];
        String bookIsbn = parts[1];
        LocalDate borrowDate = LocalDate.parse(parts[2]);
        LocalDate dueDate = LocalDate.parse(parts[3]);
        LocalDate returnDate = parts[4].equals("null") ? null : LocalDate.parse(parts[4]);
        boolean isReturned = Boolean.parseBoolean(parts[5]);

        User user = findUserById(users, userId);
        Book book = findBookByIsbn(books, bookIsbn);

        if (user == null || book == null) return null;

        BorrowRecord record = new BorrowRecord(user, book);
        record.setBorrowDate(borrowDate);
        record.setDueDate(dueDate);
        record.setReturnDate(returnDate);
        record.setReturned(isReturned);

        return record;
    }



    public ArrayList<BorrowRecord> loadBorrowedRecords(ArrayList<User> users, ArrayList<Book> books) {
        ArrayList<BorrowRecord> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(BORROWED_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                BorrowRecord record = makeBorrowObj(line, users, books);
                if (record != null) records.add(record);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Borrowed file not found. Starting fresh.");
        } catch (IOException e) {
            System.out.println("Error reading borrowed file.");
        }
        return records;
    }

    public void saveBorrowedRecords(ArrayList<BorrowRecord> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(BORROWED_FILE))) {
            for (BorrowRecord record : records) {
                bw.write(record.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving borrowed file.");
        }
    }


    private User findUserById(ArrayList<User> users, String id) {
        for (User user : users) {
            if (user.getId().equals(id)) return user;
        }
        return null;
    }

    private Book findBookByIsbn(ArrayList<Book> books, String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) return book;
        }
        return null;
    }
}